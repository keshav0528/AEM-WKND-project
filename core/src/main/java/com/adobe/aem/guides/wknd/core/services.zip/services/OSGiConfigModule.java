package com.adobe.aem.guides.wknd.core.services;

public interface OSGiConfigModule {
    public int getServiceId() ;
    public String getServiceName();
    public String getServiceURL() ;
}